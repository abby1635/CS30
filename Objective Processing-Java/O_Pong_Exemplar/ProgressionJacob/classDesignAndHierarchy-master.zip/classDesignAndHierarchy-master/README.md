# Class Design and Hierarchy

## Abstract Classes and Extending Classes
